<template>
  <div class="content_page animated zoomIn">
    <div class="content-title">
      <div class="title" v-if="!useDisabled">修改门诊治疗</div>
      <div class="title" v-if="useDisabled">查看门诊治疗</div>
      <router-link class="btn btn-info back" :to="'/hospital/treatSchedule'">
        返回
      </router-link>
    </div>
    <div class="content-show">
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">门诊方式：</div>
          <el-select ref="selectWay" size="large" :disabled="useDisabled" v-model="treatWay" class="el-field-input" placeholder="请选择">
            <el-option v-for="(item,index) in treatWayOptions" :key="index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </div>
        <div class="col-md-4 search-field" v-if="treatWay==2">
          <div class="label">预约号：</div>
          <input type="text" v-model="appointNum" :disabled="useDisabled" class="form-control input-field" />
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">马匹类型：</div>
          <el-select ref="selectType" size="large" :disabled="useDisabled" v-model="horseType" class="el-field-input" placeholder="请选择">
            <el-option v-for="(item,index) in horseTypeOptions" :key="index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </div>
        <div class="col-md-4 search-field" v-if="horseType==1">
          <div class="label">马匹名称：</div>
          <el-select size="large" :disabled="useDisabled" filterable v-model="horseName" class="el-field-input" >
            <el-option v-for="(item,index) in horseInfoName" :key="index" :label="item.horseName" :value="item.horseId">
            </el-option>
          </el-select>
        </div>
        <div class="col-md-4 search-field" v-if="horseType==2">
          <div class="label">马匹名称：</div>
          <input type="text" v-model="horseName" :disabled="useDisabled" class="form-control input-field" placeholder="请输入马匹名称" />
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">开始日期：</div>
          <el-date-picker :disabled="useDisabled" size="large" v-model="beginDate" type="date" value-format="yyyy-MM-dd" format="yyyy-MM-dd">
          </el-date-picker>
        </div>
        <div class="col-md-4 search-field">
          <div class="label">开始时间：</div>
          <el-time-select :disabled="useDisabled" size="large" v-model="beginTime" :picker-options="{
                                                                                                                  start: '00:00',
                                                                                                                  step: '01:00',
                                                                                                                  end: '24:00'
                                                                                                                }">
          </el-time-select>
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">结束日期：</div>
          <el-date-picker :disabled="useDisabled" size="large" v-model="endDate" type="date" value-format="yyyy-MM-dd" format="yyyy-MM-dd">
          </el-date-picker>
        </div>
        <div class="col-md-4 search-field">
          <div class="label">结束时间：</div>
          <el-time-select :disabled="useDisabled" size="large" v-model="endTime" :picker-options="{
                                                                                                                  start: '00:00',
                                                                                                                  step: '01:00',
                                                                                                                  end: '24:00'
                                                                                                                }">
          </el-time-select>
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">治疗名称：</div>
          <input type="text" v-model="treatName" :disabled="useDisabled" class="form-control input-field" />
        </div>
        <div class="col-md-4 search-field">
          <div class="label">手术室使用：</div>
          <el-select size="large" ref="selectUse" :disabled="useDisabled" v-model="useRoom" class="el-field-input" placeholder="请选择">
            <el-option v-for="(item,index) in consultingRoomList" :key="index" :label="item.consultingRoomName" :value="item.consultingRoomId">
            </el-option>
          </el-select>
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-4 search-field">
          <div class="label">设备使用：</div>
          <textarea type="text" rows="2" v-model="hospitalAssetList" :useDisabled="useDisabled" class="form-control addborder" @click="getAssetsList(1)" placeholder="点击查看详情"></textarea>
        </div>
        <div class="col-md-4 search-field">
          <div class="label">消耗品使用：</div>
          <textarea type="text" rows="2" v-model="consumableAssetList" :useDisabled="useDisabled" class="form-control addborder" @click="getConsumeList(1)" placeholder="点击查看详情"></textarea>
        </div>
      </div>
      <div class="row list-search">
        <div class="col-md-12 search-field">
          <div class="label">治疗概述：</div>
          <el-input type="textarea" :rows="3" :cols="2" :disabled="useDisabled" v-model="treatDesc" placeholder="请输入治疗概述"></el-input>
        </div>
      </div>
    </div>
    <div class="content-footer row" v-show="!useDisabled">
      <el-button class="col-md-1 btn btn-primary makesure" :plain="true" @click="updateTreat">确定</el-button>
    </div>
    <el-dialog title="查看设备" :modal-append-to-body="false" class="content-show" :visible.sync="addItemDialog" width="50%" center>
      <div class="row list-search">
        <div class="col-md-8 search-field">
          <div class="label" style="left:-18px">固定资产名称：</div>
          <input type="text" v-model="assetsTreatName" class="form-control input-field" placeholder="请输入资产名称" />
        </div>
        <div class="col-md-1 search-field search-field_controls">
          <button @click="getAssetsList(1)" class="btn btn-primary search-btn">搜索</button>
        </div>
      </div>
      <div class="list-empty" v-show="assetsList.length==0">
        暂无数据
      </div>
      <el-form ref="form" class="ml-3 mb-1" v-for="(item,index) in assetsList" :key="index" :inline="true"  label-width="98px">
        <el-form-item>
          <el-checkbox disabled v-model="item.checked" checked></el-checkbox>
        </el-form-item>
        <el-form-item label="固定资产名称">
          <el-input type="text" disabled v-model="item.assetName" placeholder="资产名称" />
        </el-form-item>
        <el-form-item label="数量">
          <el-input type="text" disabled v-model="item.inventory" placeholder="库存" />
        </el-form-item>
        <el-form-item>
          <div class="Spinner">
            <button class="Decrease" disabled @click="decrease(index,item.useNumber)">
              <i class="fa fa-sort-desc"></i>
            </button>
            <input class="Amount" disabled v-model="item.useNumber" placeholder="使用数量" autocomplete="off">
            <button class="Increase" disabled @click="increase(index,item.useNumber,item.inventory)">
              <i class="fa fa-sort-asc"></i>
            </button>
          </div>
        </el-form-item>
      </el-form>
      <div class="page">
        <el-pagination @current-change="getAssetsList" :current-page="currentPage" :page-size="pageRecorders" background layout="prev, pager, next" :total="totalRecorders">
        </el-pagination>
      </div>
      <!-- <span slot="footer" class="dialog-footer">
                                                <el-button @click="addItemDialog = false">取 消</el-button>
                                                <el-button type="primary" @click="addItemDialog = false">确 定</el-button>
                                              </span> -->
    </el-dialog>
    <el-dialog title="查看消耗品" :modal-append-to-body="false" class="content-show" :visible.sync="addConsumeDialog" width="50%" center>
      <div class="row list-search">
        <div class="col-md-8 search-field">
          <div class="label">消耗品名称：</div>
          <input type="text" v-model="consumeTreatName" class="form-control input-field" placeholder="请输入消耗品名称" />
        </div>
        <div class="col-md-1 search-field search-field_controls">
          <button @click="getConsumeList(1)" class="btn btn-primary search-btn">搜索</button>
        </div>
      </div>
      <div class="list-empty" v-show="consumeList.length==0">
        暂无数据
      </div>
      <el-form ref="form" class="ml-3 mb-1" v-for="(item,index) in consumeList" :key="index" :inline="true"  label-width="88px">
        <el-form-item>
          <el-checkbox disabled v-model="item.checked" checked></el-checkbox>
        </el-form-item>
        <el-form-item label="消耗品名称">
          <el-input type="text" disabled v-model="item.assetName" placeholder="消耗品名称" />
        </el-form-item>
        <el-form-item label="数量">
          <el-input type="text" disabled v-model="item.inventory" placeholder="库存" />
        </el-form-item>
        <el-form-item>
          <div class="Spinner">
            <button class="Decrease" disabled @click="decreaseConsume(index,item.useNumber)">
              <i class="fa fa-sort-desc"></i>
            </button>
            <input disabled class="Amount" v-model="item.useNumber" placeholder="使用数量" autocomplete="off">
            <button disabled class="Increase" @click="increaseConsume(index,item.useNumber,item.inventory)">
              <i class="fa fa-sort-asc"></i>
            </button>
          </div>
        </el-form-item>
      </el-form>
      <div class="page">
        <el-pagination @current-change="getConsumeList" :current-page="current" :page-size="page" background layout="prev, pager, next" :total="total">
        </el-pagination>
      </div>
      <!-- <span slot="footer" class="dialog-footer">
                                                <el-button @click="addConsumeDialog = false">取 消</el-button>
                                                <el-button type="primary" @click="addConsumeDialog = false">确 定</el-button>
                                              </span> -->
    </el-dialog>
  </div>
</template>
<script>
import {
  Form,
  DatePicker,
  Button,
  TimeSelect,
  Input,
  Message,
  Select,

} from "element-ui";
import hospitalSrv from "../../../services/hospital.service.js";
import hosAssetsSrv from "../../../services/hosAssets.service.js";
import horseSrv from "../../../services/horse.service.js";
export default {
  data() {
    return {
      treatmentId: "",
      useDisabled: false,
      addConsumeDialog: false,
      addItemDialog: false,
      consultingRoomList: [],
      consumableAssetList: [],
      horseInfoName: [],
      horseName: "",
      treatName: "",
      consumeTreatName: "",
      assetsTreatName: "",
      treatDesc: "",
      appointNum: "",
      treatDate: "",
      useConsume: [],
      treatWay: "",
      beginDate: "",
      beginTime: "",
      endDate: "",
      endTime: "",
      horseType: "",
      useRoom: "",
      assetsName: "",
      currentPage: 1,
      pageRecorders: 5,
      totalRecorders: 1,
      current: 1,
      page: 5,
      total: 1,
      assetsList: [],
      consumeList: [],
      hospitalAssetList: [],
      treatWayOptions: [
        {
          value: 1,
          label: "普通"
        },
        {
          value: 2,
          label: "预约"
        }
      ],
      horseTypeOptions: [
        {
          value: 1,
          label: "中心"
        },
        {
          value: 2,
          label: "外来"
        }
      ]
    };
  },
    beforeRouteLeave(to, from, next) {
        to.meta.keepAlive = true
        next()
    },
  beforeRouteEnter: function(to, from, next) {
    next(vm => {
      vm.treatmentId = to.query.treatmentId;
      hospitalSrv.getTreatDetail(to.query.treatmentId).then(
        resp => {
          vm.treatWay = resp.data.outpatientType;
          vm.appointNum = resp.data.appointNumber;
          vm.beginDate = resp.data.beginDate;
          vm.beginTime = resp.data.beginTime.slice(0, 5);
          vm.endDate = resp.data.endDate;
          vm.endTime = resp.data.endTime.slice(0, 5);
          vm.horseType = resp.data.horseType;
          // if (vm.horseType == 1) {
          //   vm.horseName = resp.data.horseId;
          // } else {
            vm.horseName = resp.data.horseName;
          // }
          vm.treatName = resp.data.treatName;
          vm.treatDesc = resp.data.treatDesc;
          vm.useRoom = resp.data.consultingRoomId;
        },
        err => {
          vm.$message.error(err.msg);
        }
      );
      horseSrv.getHorseName().then(
        resp => {
          vm.horseInfoName = resp.data.horseList;
        },
        err => {
          vm.$message.error(err.msg);
        }
      );
      hospitalSrv.getOperateRoomBox().then(
        resp => {
          vm.consultingRoomList = resp.data.consultingRoomList;
        },
        err => {
          vm.$message.error(err.msg);
        }
      );
    });
  },
  mounted() {
    this.useDisabled = !!this.$route.query.disable;
    this.$el.addEventListener("animationend", this.resizeWay);
    this.$el.addEventListener("animationend", this.resizeType);
    this.$el.addEventListener("animationend", this.resizeUse);
  },
  methods: {
    resizeWay() {
      this.$refs.selectWay.resetInputWidth();
    },
    resizeType() {
      this.$refs.selectType.resetInputWidth();
    },
    resizeUse() {
      this.$refs.selectUse.resetInputWidth();
    },
    getAssetsList(currentPage = this.currentPage) {
      this.addItemDialog = true;
      hosAssetsSrv
        .assetsList(
        currentPage,
        this.pageRecorders,
        "",
        "",
        this.assetsTreatName
        )
        .then(
        resp => {
          this.currentPage = currentPage;
          this.totalRecorders = resp.data.totalRecorders;
          let assetsList = resp.data.assetInfoList;
          let len = assetsList.length;
          for (let i = 0; i < len; i++) {
            assetsList[i].checked = true;
            assetsList[i].useNumber = 1;
          }
          this.assetsList = assetsList;
        },
        err => {
          this.$message.error(err.msg);
        }
        );
    },
    getConsumeList(currentPage = this.current) {
      this.addConsumeDialog = true;
      hosAssetsSrv
        .consumeList(currentPage, this.page, "", "", this.consumeTreatName)
        .then(
        resp => {
          this.current = currentPage;
          this.total = resp.data.totalRecorders;
          let consumeList = resp.data.assetInfoList;
          let len = consumeList.length;
          for (let i = 0; i < len; i++) {
            consumeList[i].checked = true;
            consumeList[i].useNumber = 1;
          }
          this.consumeList = consumeList;
        },
        err => {
          this.$message.error(err.msg);
        }
        );
    },
    updateTreat() {
      if (this.treatWay == 2 && !this.appointNum) {
        this.$message.error("预约号不能为空！");
        return;
      }
      if (
        !(
          this.treatWay &&
          this.beginDate &&
          this.beginTime &&
          this.endDate &&
          this.endTime &&
          this.horseType &&
          this.horseName &&
          this.treatName &&
          this.treatDesc &&
          this.useRoom
        )
      ) {
        this.$message.error("治疗信息不能为空！");
        return;
      }
      let treatInfo = {
        treatmentId: this.treatmentId,
        outpatientType: this.treatWay,
        // appointNumber: this.appointNum,
        beginDate: this.beginDate,
        beginTime: this.beginTime + ":00",
        endDate: this.endDate,
        endTime: this.endTime + ":00",
        horseType: this.horseType,
        horseId: this.horseName,
        horseName: this.horseName,
        treatName: this.treatName,
        treatDesc: this.treatDesc,
        consultingRoomId: this.useRoom,
      };
      if (this.treatWay == 2) {
        treatInfo.appointNumber = this.appointNum;
      }
      hospitalSrv.updateTreat(treatInfo).then(
        resp => {
          this.$message.success("修改治疗信息成功");
          this.$router.push("/hospital/treatSchedule");
        },
        err => {
          this.$message.error(err.msg);
        }
      );
    },
    increase(index, value, inventory) {
      if (value >= inventory) {
        return inventory;
      } else {
        return this.assetsList[index].useNumber++;
      }
    },
    //减少
    decrease(index, value) {
      this.index = index;
      if (value <= 0) {
        return 0;
      } else {
        return this.assetsList[index].useNumber--;
      }
    },
    increaseConsume(index, value, inventory) {
      if (value >= inventory) {
        return inventory;
      } else {
        return this.consumeList[index].useNumber++;
      }
    },
    //减少
    decreaseConsume(index, value) {
      this.index = index;
      if (value <= 0) {
        return 0;
      } else {
        return this.consumeList[index].useNumber--;
      }
    },

    uploadFun(file) {
      this.files[file.name] = file.file;
    },
    successFile(res) {
      //上传成功后，接口返回的值，点击确定把这个值再传过去
      console.log(res);
    },
    removeFile(file) {
      console.log(file);
    },
    open() {
      this.$message.success("修改成功");
    }
  }
};
</script>

<style lang="scss" scoped>
.addborder {
  border-radius: 5px;
}

.add-delete a {
  margin-left: 5px;
  cursor: pointer;
}

.add-delete {
  color: #409eff;
  margin-left: -40px;
  float: left;
  font-size: 40px;
  display: inline-flex;
}

.input-field {
  border-radius: 5px;
  height: 40px;
}

.Spinner {
  display: block;
  overflow: hidden;
  width: 160px;
}

.Spinner button {
  // display: inline-block;
  width: 35px;
  height: 35px;
  border: 1px solid #d9d9d9;
  background-color: #f7f7f7;
  float: left;
  cursor: pointer;
  outline: 0;
}

.Spinner .Amount {
  width: 50px;
  height: 35px;
  border-width: 1px 0;
  border-style: solid;
  border-color: #d9d9d9;
  float: left;
  text-align: center;
  color: #560606;
  outline: 0;
}

.Decrease {
  border-radius: 5px 0 0 5px;
}

.Increase {
  border-radius: 0 5px 5px 0;
}

.Decrease i {
  // padding-left: 10px;
  font-size: 20px;
  color: #409eff;
  margin-top: -18px;
}

.Increase i {
  // padding-left: 10px;
  margin-top: -18px;
  position: relative;
  top: 8px;
  font-size: 22px;
  color: #409eff;
}

.baseInfo-title {
  height: 30px;
  line-height: 30px;
  border-left: 2px solid #2db7f5;
  padding-left: 20px;
  padding-right: 20px;
  margin-bottom: 12px;
  .title {
    font-size: 16px;
    font-weight: bold;
    display: inline-block;
  }
}
</style>
